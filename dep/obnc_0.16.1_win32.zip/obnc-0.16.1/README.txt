INTRODUCTION

OBNC is a compiler for Niklaus Wirth's programming language Oberon. It translates Oberon modules into C code. The build command (obnc) invokes both the Oberon compiler (obnc-compile) and a C compiler, and sorts out all dependencies. For more information, see the project home page at https://www.miasap.se/obnc.

This is a precompiled version for Microsoft Windows (Win32). The package is self-contained and includes the following packages on which OBNC depends:

	Gawk 3.1.6-1
		https://www.gnu.org/software/gawk

	GC 7.6.4
		http://www.hboehm.info/gc

	libatomic_ops 7.6.6
		https://github.com/ivmai/libatomic_ops

	SDL 1.2.15
		https://www.libsdl.org

	TinyCC 0.9.26
		https://bellard.org/tcc

All of the above packages are free software. For licencing details, see the respective website.

For interactive use, each OBNC command has a batch file and a POSIX shell script in the top directory. These scripts set the proper environment before executing the corresponding command in the bin folder.


INSTALLATION

To install OBNC you can put the package directory anywhere. For a global installation the recommended location is "C:\Program Files (x86)". To run OBNC commands without a path and to let the compiled programs find the required dynamic link libraries (.dll files) you also need to add the OBNC package path to the PATH environment variable, for example by typing

	SETX PATH=%PATH%;C:\Program Files (x86)\obnc-x.y.z

at the command prompt (where x.y.z should be replaced with the actual version). Alternatively, the PATH can be set in the Windows Control Panel. If you want to make programs compiled with OBNC independent of the OBNC installation you need to copy the .dll files in the top directory of the package to either your program directories or to the Windows system directory.


LICENSE

OBNC is released under the GNU General Public License (https://www.gnu.org/licenses/gpl-3.0.html), with the exception of library files in lib/obnc which are released under the Mozilla Public License (https://www.mozilla.org/en-US/MPL/2.0/).


AUTHOR

Karl Landstrom <karl@miasap.se>
